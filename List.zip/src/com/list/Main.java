package com.list;

public class Main {

	public static void main(String[] args) {

		Celebrity celebrity = new Celebrity();
		celebrity.run();

	}

}
